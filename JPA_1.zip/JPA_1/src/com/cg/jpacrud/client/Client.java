package com.cg.jpacrud.client;

import javax.rmi.CORBA.Stub;

import com.cg.japcrud.service.AuthorServiceImpl;
import com.cg.jpacrud.entites.Author;

public class Client {

	public static void main(String[] args) {
		AuthorServiceImpl service = new AuthorServiceImpl();

		Author author = new Author();

		author.setAuthorId(100);
		author.setFirstName("mohit");
		author.setLastName("pro");
		author.setMiddleName("p");
		author.setPhoneNo("12345999");

		service.addAuthor(author);

		author.setFirstName("mohitGG");

		service.updateAuthor(author);

		author = service.findStudentById(100);
		System.out.print("ID:" + author.getAuthorId());
		System.out.println(" Name:" + author.getFirstName());

		service.removeAuthor(author);

	}
}
