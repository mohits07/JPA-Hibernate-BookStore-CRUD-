package com.cg.japcrud.service;

import com.cg.japcrud.dao.AuthorDaoImpl;
import com.cg.jpacrud.entites.Author;

public class AuthorServiceImpl implements AuthorService {
	AuthorDaoImpl dao;
	public AuthorServiceImpl() {
		dao = new AuthorDaoImpl();
	}

	@Override
	public void addAuthor(Author author) {
		dao.beginTransaction();
		dao.addStudent(author);
		dao.commitTransaction();
		System.out.println("Author recrod added successfully");
	}

	@Override
	public void updateAuthor(Author author) {
		// TODO Auto-generated method stub
		dao.beginTransaction();
		dao.updateStudent(author);
		dao.commitTransaction();
		
	}

	@Override
	public void removeAuthor(Author author) {
		dao.beginTransaction();
		dao.removeStudent(author);
		dao.commitTransaction();
		
	}

	@Override
	public Author findStudentById(int id) {
		
		Author author = dao.getStudentById(id);
		return author;
		
	}

}
