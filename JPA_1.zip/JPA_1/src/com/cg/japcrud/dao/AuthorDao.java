package com.cg.japcrud.dao;

import com.cg.jpacrud.entites.Author;


public interface AuthorDao {

	
	public abstract Author getStudentById(int id);

	public abstract void addStudent(Author author);

	public abstract void removeStudent(Author author);

	public abstract void updateStudent(Author author);

	public abstract void commitTransaction();

	public abstract void beginTransaction();

}
